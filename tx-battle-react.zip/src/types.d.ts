declare module '@farcaster/miniapp-sdk';
