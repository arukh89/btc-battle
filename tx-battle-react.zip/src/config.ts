export const BACKEND_URL = "https://3ffe2d34-7fa9-4492-bdc8-68e9a2b9f021-00-3hy09jgnwmhu3.sisko.replit.dev";
export const FRONTEND_URL = "https://testtx.netlify.app/";
export const OG_IMAGE = FRONTEND_URL + "og.svg";
